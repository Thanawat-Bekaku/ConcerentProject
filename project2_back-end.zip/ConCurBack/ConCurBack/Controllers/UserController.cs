﻿using ConCurBack.Model;
using ConCurBack.Service;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ConCurBack.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly IUserService userService;
        public UserController(IUserService _userservice)
        {
            userService = _userservice;
        }


        [HttpPost]
        public string AddUser(AddUser addUser)
        {
            var userdata = userService.AddDataToDataBase(addUser.Username, addUser.Password, addUser.Name, addUser.Surname, addUser.Phone);
            return "Add Success!!!!";
        }
        [HttpGet]
        public async Task<ActionResult<List<UserData>>> GetAllUser()
        {
            var userdata = await userService.GetAllUser();
            return userdata;
        }
        [HttpDelete("{ID}")]
        public string DeleteUser(long ID)
        {
            userService.DeleteUse(ID);

            return "Delete Success!!!!";
            
        }




    }
}
