﻿using ConCurBack.Model;
using Dapper;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConCurBack.Service
{
    public interface IUserService
    {
        Task<List<UserData>> GetAllUser();
        Task<List<UserData>> AddDataToDataBase(string username, string password, string name, string surname, string phone);
        void DeleteUse(long id);
    }
    public class UserService : IUserService
    {
        private readonly IConfiguration _con;
        public UserService(IConfiguration con)
        {
            _con = con;
        }
        public IDbConnection ConnectionUserData
        {
            get
            {
                return new SqlConnection(_con.GetConnectionString("DatabaseConfig"));
            }
        }

        public async Task<List<UserData>> GetAllUser()
        {
            string sql = "select * from UserData";
            using (IDbConnection conn = ConnectionUserData)
            {
                conn.Open();
                var result = await conn.QueryAsync<UserData>(sql);
                return result.ToList();
            }
        }
        public async Task<List<UserData>> AddDataToDataBase(string username,string password, string name, string surname, string phone)
        {
            StringBuilder sql = new StringBuilder();
            sql.Append("Insert into UserData (Username,Password,Name,Surname,Phone) ");
            sql.Append("VALUES (@username,@password,@name,@surname,@phone)");
            using (IDbConnection conn = ConnectionUserData)
            {
                conn.Open();
                var result = await conn.QueryAsync<UserData>(sql.ToString(), new { username, password, name, surname, phone });
                return result.ToList();
            }
        }
        public void DeleteUse(long id)
        {
            string sql = "delete from UserData where ID = @id";
            using (IDbConnection conn = ConnectionUserData)
            {
                conn.Open();
                conn.Execute(sql, new { id });
            }
        }
        public void UpdateUser()
        { 
        
        }
    }
}
