﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ConCurBack.Model
{
    public class ConnectDBClass : DbContext
    {
        public ConnectDBClass(DbContextOptions<ConnectDBClass> options):base(options)
        { 

        }
    }
}
